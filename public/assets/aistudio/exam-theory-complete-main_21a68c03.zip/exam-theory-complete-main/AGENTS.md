<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the medical study reader in a shrinking-safe grid with an optional desktop contents column and an on-demand mobile sheet, so navigation never occupies the mobile reading viewport.
- Render existing medical text without changing clinical values; presentation-only emphasis may highlight original labels and topic tags.
- Derive recall quizzes from existing section questions and exact model answers; use explicit self-assessment instead of unreliable automatic grading of free-text medical answers, and keep quiz results in session state separate from topic mastery.
- Reading focus is reversible UI state: hide navigation and ancillary reader chrome without removing theory or clinical warnings, preserving an exit control and Escape handling.
- Split dense medical prose for display only via splitPoints (top-level semicolons, numbered markers, sentence ends; never inside brackets or at commas), with a test proving the text is unchanged.
- Researched content that fills exam-scope gaps lives in src/medmaster/data/scope/*.ts and is appended by mergeScope; never edit original document text in masterDocData.ts so researched material stays distinguishable and cited.
- Keep explanatory learning guides separate from original clinical text and render them before continuous theory; exam notes, protocol comparisons and recall follow the whole chapter so they do not interrupt its conceptual sequence, while safety warnings remain visible.
