# Reading layout refresh
- [x] Make contents collapsible and prevent obstruction on small screens.
- [x] Improve theory typography, section navigation, colour cues and visual aids without changing medical content.
- [x] Verify reading, topic switching and existing study controls on desktop and mobile.

# Focus and recall
- [x] Add a soft, colourful pastel study theme.
- [x] Add reading focus mode with an always-available exit.
- [x] Add typed recall quizzes, model-answer comparison, self-assessment, session results and retrying missed questions.
- [x] Test quiz rules and verify focus and quiz flows on desktop and phone.

# Calmer systematic study
- [x] Replace mixed pastels with quiet tonal colours and soft rounded surfaces.
- [x] Present dense theory and answers as separate readable points, preserving clinical text.
- [x] Add source-grounded memory pathways and previous/next topic controls.
- [x] Test text preservation and topic order; verify phone and desktop reading flows.
# Exam scope coverage
- [x] Audit every scope bullet against existing theory (8 parallel system audits).
- [x] Add researched, SA-guideline-first theory for missing topics in separate scope files, with sources and recall questions.
- [x] Test that original text is untouched and new sections are complete; verify reading on phone.

# Uploaded scope and question compilation review
- [ ] Audit the supplied detailed scope and all 61 pages of question prompts against substantive theory (8 system audits running).
- [x] Make theory the default reading flow, with notes and recall after the main concepts and visible safety warnings.
- [ ] Add source-grounded connecting explanations (every topic, incl. researched ones) and document remaining coverage gaps honestly in an audit report.
- [ ] Run content-preservation tests and verify reading, notes and recall on phone and desktop.
