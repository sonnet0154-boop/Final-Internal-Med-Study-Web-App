import { createFileRoute, ClientOnly } from "@tanstack/react-router";
import App from "@/medmaster/App";

const title = "Approach to Everything: Internal Medicine Master Doc";
const description =
  "ADHD-friendly South African internal medicine exam master doc with SA STG/EML protocols, 2024–2026 guidelines, active recall and cases.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <ClientOnly fallback={<div className="min-h-screen bg-background" />}>
      <App />
    </ClientOnly>
  );
}
