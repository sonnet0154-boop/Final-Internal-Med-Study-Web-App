# Remix of Medmaster Study Nook

https://github.com/sonnet0154-boop/MedMaster-Doc.git Can you host this app as a web app i can visit to study instead of just preview

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://med-mind-recall-garden.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/62abf0ff-d62a-4e38-b97d-ef7dea9b756a).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
